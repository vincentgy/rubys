<?php

// Heading Goes here:
$_['heading_title']    = 'Blog Popular Posts';

// Text
$_['text_success']     = 'Success: You have modified module Blog Popular Posts!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Blog Popular Posts!';
