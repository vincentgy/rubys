<?php
// Heading
$_['heading_title']     = 'Chuang Lan China Main Land & International Sms';

// Text
$_['text_sms']    	    = 'Sms';
$_['text_success']      = 'Success: You have modified chuanglan sms!';
$_['text_edit']         = 'Edit ChuangLan Sms';

// Entry
$_['entry_account']     = 'Account';
$_['entry_password']    = 'Password';
$_['entry_status'] 		= 'Status';

// Error
$_['error_permission'] 	= 'Warning: You do not have permission to modify chuanglan sms!';
$_['error_account'] 	= 'Account Required!';
$_['error_password'] 	= 'Password Required!';
