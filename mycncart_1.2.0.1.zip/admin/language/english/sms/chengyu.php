<?php
// Heading
$_['heading_title']    = 'ChengYu Sms';

// Text
$_['text_sms']    	   = 'Sms';
$_['text_success']     = 'Success: You have modified chengyu sms!';
$_['text_edit']        = 'Edit ChengYu Sms';

// Entry
$_['entry_userid']      = 'User ID';
$_['entry_account']     = 'Account';
$_['entry_password']    = 'Password';
$_['entry_status'] 		= 'Status';

// Error
$_['error_permission'] 	= 'Warning: You do not have permission to modify chengyu sms!';
$_['error_userid'] 		= 'User ID Required!';
$_['error_account'] 	= 'Account Required!';
$_['error_password'] 	= 'Password Required!';