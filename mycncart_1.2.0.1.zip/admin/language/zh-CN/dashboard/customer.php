<?php

// Heading
$_['heading_title'] = '总会员数量';

// Text
$_['text_view'] = '查看更多......';