<?php

// Heading
$_['heading_title']    = '文章';

// Text
$_['text_module']      = '模组';
$_['text_success']     = '成功: 已修改文章模组！';
$_['text_edit']        = '编辑文章模组';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告: 无权限修改文章模组！';