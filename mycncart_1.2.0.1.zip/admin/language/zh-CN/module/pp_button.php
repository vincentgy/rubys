<?php

// Heading
$_['heading_title']    = 'PayPal Express Checkout 按钮';

// Text
$_['text_module']      = '模组';
$_['text_success']     = '成功: 已修改PayPal Express Checkout 按钮模组！';
$_['text_edit']        = '编辑 PayPal Express Checkout 按钮模组';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告: 无权限修改 PayPal Express Checkout 按钮模组！';