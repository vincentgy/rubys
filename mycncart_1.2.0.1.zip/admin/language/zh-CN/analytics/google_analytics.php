<?php
$_['heading_title']    = '谷歌分析';

// Text
$_['text_analytics']   = '分析';
$_['text_success']	   = '成功: 已修改谷歌分析!';
$_['text_edit']        = '编辑谷歌分析';
$_['text_signup']      = '登录您在 <a href="http://www.google.com/analytics/" target="_blank"><u>谷歌分析网站</u></a> 的账户，然后创建您的网站资料，然后复制并粘贴分析代码到此处。';

// Entry
$_['entry_code']       = '谷歌分析代码';
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告: 无权限修改谷歌分析！';
$_['error_code']	   = '代码必填！';
