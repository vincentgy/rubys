<?php

// Heading
$_['heading_title']     = '订单小计项';

// Text
$_['text_success']      = '成功: 已修改订单小计项！';
$_['text_list']         = '订单小计项列表';

// Column
$_['column_name']       = '订单小计项';
$_['column_status']     = '状态';
$_['column_sort_order'] = '排序';
$_['column_action']     = '操作';

// Error
$_['error_permission']  = '警告: 无权限修改订单小计项！';