<?php

// Heading
$_['heading_title']     = '支付方式';

// Text
$_['text_success']      = '成功: 已修改支付方式！';
$_['text_list']         = '支付方式列表';

// Column
$_['column_name']       = '支付方式';
$_['column_status']     = '状态';
$_['column_sort_order'] = '排序';
$_['column_action']     = '操作';

// Error
$_['error_permission']  = '警告: 无权限修改支付方式！';