<?php

// Heading
$_['heading_title']     = '配送方式';

// Text
$_['text_success']      = '成功: 已修改配送方式！';
$_['text_list']         = '配送方式列表';

// Column
$_['column_name']       = '配送方式';
$_['column_status']     = '状态';
$_['column_sort_order'] = '排序';
$_['column_action']     = '操作';

// Error
$_['error_permission']  = '警告: 无权限修改配送方式！';