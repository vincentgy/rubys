<?php

$_['text_complete_status']   = '已完成订单'; 
$_['text_processing_status'] = '处理中订单'; 
$_['text_other_status']      = '其它状态订单'; 