<?php

// Text
$_['text_approve_subject']      = '%s - 您的推广会员账户已被激活！';
$_['text_approve_welcome']      = '欢迎您在 %s 注册！';
$_['text_approve_login']        = '您的账户已被建立，您可以使用电邮地址和密码点击如下链接登录网站:';
$_['text_approve_services']     = '登录后，您可以创建跟踪代码，跟踪佣金收入，以及编辑账户信息。';
$_['text_approve_thanks']       = '谢谢,';
$_['text_transaction_subject']  = '%s - 推广佣金';
$_['text_transaction_received'] = '您收到了 %s 佣金！';
$_['text_transaction_total']    = '总佣金收入现在为 %s 。';