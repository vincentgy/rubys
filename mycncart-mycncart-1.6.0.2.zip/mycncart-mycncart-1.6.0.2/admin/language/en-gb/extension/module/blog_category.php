<?php
// Heading
$_['heading_title']    = 'Blog Category';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified blog category module!';
$_['text_edit']        = 'Edit Blog Category Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify blog category module!';