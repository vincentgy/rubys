<?php
/**
 * Tiny - A PHP Framework For Web Artisans
 * @author Tiny <tinylofty@gmail.com>
 * @copyright Copyright(c) 2010-2014 http://www.tinyrise.com All rights reserved
 * @version 1.0
 */
/**
 * 模块事件 
 * @author Tiny
 * @class ModelEvent
 */
class ModelEvent extends Event
{
	public $isValid =  true;
}
