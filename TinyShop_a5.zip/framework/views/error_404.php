<html><head>
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<title>404 Not Found 访问的网页不存在</title>
<style>
body {font-family:"微软雅黑",arial,sans-serif}
a{font-size:12px;}
</style>
</head>
<body text=#000000 bgcolor=#ffffff>
<table border=0 cellpadding=2 cellspacing=0 width=100%><tr><td rowspan=3 width=1% nowrap>
<b><font face=times color=#0039b6 size=10>M</font><font face=times color=#c41200 size=10>e</font><font face=times color=#f3c518 size=10>s</font><font face=times color=#0039b6 size=10>s</font><font face=times color=#30a72f size=10>a</font><font face=times color=#c41200 size=10>g</font><font face=times color=#0039b6 size=10>e</font>&nbsp;&nbsp;</b></td>

<td>&nbsp;</td></tr>
<tr><td bgcolor="#3366cc" ><font face=arial,sans-serif style="color:#FFF;line-height:32px;"><b>404Error</b></font></td></tr>
<tr><td>&nbsp;</td></tr></table>
<blockquote>
<H1>没有找到您要访问的页面</H1>
The requested URL was not found on this server.   
<ol>    
<li>请检查您输入的网址是否正确。</li>
<li>确认无误有可能我们的页面正在升级或维护。</li>
<li>您可以尝试稍后访问。</li>   
</ol>
</blockquote>
</body></html>