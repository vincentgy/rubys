<?php
// Heading
$_['heading_title']    = 'Press Latest';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified press latest module!';
$_['text_edit']        = 'Edit Press Latest Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify press latest module!';