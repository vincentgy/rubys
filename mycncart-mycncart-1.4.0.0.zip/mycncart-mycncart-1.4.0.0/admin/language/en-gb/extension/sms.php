<?php
// Heading
$_['heading_title']     = 'SMS';

// Text
$_['text_success']      = 'Success: You have modified SMS!';
$_['text_list']         = 'Sms List';

// Column
$_['column_name']       = 'SMS Method';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Sort Order';
$_['column_action']     = 'Action';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify SMS!';